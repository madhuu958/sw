
import React, { useState, useEffect, useCallback } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import TileSimulator from './components/TileSimulator';
import Analytics from './components/Analytics';
import { EnergyReading, SystemStats } from './types';
import { Share2, Bell, Settings, Search } from 'lucide-react';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [history, setHistory] = useState<EnergyReading[]>([]);
  const [stats, setStats] = useState<SystemStats>({
    totalSteps: 0,
    totalEnergyGenerated: 0,
    peakVoltage: 0,
    efficiency: 92.4,
    currentStatus: 'Active'
  });

  const handleNewReading = useCallback((reading: EnergyReading) => {
    setHistory(prev => [...prev.slice(-99), reading]);
    setStats(prev => ({
      ...prev,
      totalSteps: prev.totalSteps + 1,
      totalEnergyGenerated: prev.totalEnergyGenerated + reading.energy,
      peakVoltage: Math.max(prev.peakVoltage, reading.voltage)
    }));
  }, []);

  return (
    <div className="flex bg-slate-50 min-h-screen text-slate-900 font-sans">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="ml-64 flex-1 flex flex-col min-h-screen">
        {/* Top Navigation / Header */}
        <header className="h-20 border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-40 px-8 flex items-center justify-between">
          <div className="flex items-center gap-4 bg-slate-100 px-4 py-2 rounded-2xl border border-slate-200">
            <Search className="w-4 h-4 text-slate-400" />
            <input 
              type="text" 
              placeholder="Search nodes or metrics..." 
              className="bg-transparent border-none outline-none text-sm w-64 placeholder:text-slate-400"
            />
          </div>

          <div className="flex items-center gap-3">
            <button className="p-2.5 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-100 transition-colors">
              <Share2 className="w-5 h-5" />
            </button>
            <button className="p-2.5 rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-100 transition-colors relative">
              <Bell className="w-5 h-5" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="w-[1px] h-6 bg-slate-200 mx-2"></div>
            <button className="flex items-center gap-3 bg-slate-900 text-white pl-4 pr-2 py-1.5 rounded-xl hover:bg-slate-800 transition-colors">
              <span className="text-sm font-bold">Admin Portal</span>
              <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center">
                <Settings className="w-4 h-4 text-slate-900" />
              </div>
            </button>
          </div>
        </header>

        {/* Content Area */}
        <div className="p-8 max-w-7xl mx-auto w-full">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight">
                {activeTab === 'dashboard' && 'Station Main Hub'}
                {activeTab === 'simulator' && 'Piezo Simulation'}
                {activeTab === 'analytics' && 'AI Forecasting'}
                {activeTab === 'iot' && 'IoT Infrastructure'}
              </h1>
              <p className="text-slate-500 mt-1 font-medium">
                {activeTab === 'dashboard' && 'Monitoring node WP-NODE-X0429 in real-time'}
                {activeTab === 'simulator' && 'Hardware testing environment for piezoelectric material response'}
                {activeTab === 'analytics' && 'Deep learning insights for urban energy management'}
                {activeTab === 'iot' && 'ESP32 Gateway and mesh network configuration'}
              </p>
            </div>
            
            {activeTab === 'dashboard' && (
              <div className="flex gap-2">
                 <div className="px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100 flex items-center gap-2">
                   <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                   <span className="text-sm font-bold">LIVE FEED</span>
                 </div>
              </div>
            )}
          </div>

          <div className="min-h-[600px]">
            {activeTab === 'dashboard' && <Dashboard history={history} stats={stats} />}
            {activeTab === 'simulator' && <TileSimulator onStep={handleNewReading} />}
            {activeTab === 'analytics' && <Analytics history={history} />}
            {activeTab === 'iot' && (
              <div className="bg-white p-12 rounded-3xl border border-slate-200 shadow-sm flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-20 h-20 bg-slate-100 rounded-3xl flex items-center justify-center border border-slate-200">
                  <Share2 className="w-10 h-10 text-slate-400" />
                </div>
                <div className="max-w-md">
                  <h3 className="text-xl font-bold text-slate-800">Node Configuration Mesh</h3>
                  <p className="text-slate-500 mt-2">Manage your fleet of Walk To Power tiles. Register new ESP32 modules, update firmware over-the-air, or configure gateway endpoints.</p>
                </div>
                <button className="bg-slate-900 text-white px-8 py-3 rounded-2xl font-bold hover:bg-slate-800 transition-all shadow-xl shadow-slate-900/10">
                  Scan for New Nodes
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Footer info */}
        <footer className="mt-auto p-8 border-t border-slate-200 bg-white">
          <div className="flex justify-between items-center opacity-50 hover:opacity-100 transition-opacity">
            <p className="text-xs font-bold text-slate-500 uppercase tracking-widest">&copy; 2025 Walk To Power - Sustainable Urban Solutions</p>
            <div className="flex gap-6 text-xs font-bold text-slate-500 uppercase tracking-widest">
              <span>Security Hub</span>
              <span>API Docs</span>
              <span>Support</span>
            </div>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default App;
