
import React from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  AreaChart, Area, BarChart, Bar, Cell
} from 'recharts';
import { Zap, TrendingUp, Battery, Gauge } from 'lucide-react';
import { EnergyReading, SystemStats } from '../types';

interface DashboardProps {
  history: EnergyReading[];
  stats: SystemStats;
}

const Dashboard: React.FC<DashboardProps> = ({ history, stats }) => {
  const chartData = history.slice(-30).map(h => ({
    time: new Date(h.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    voltage: h.voltage.toFixed(2),
    power: h.power.toFixed(2),
    energy: h.energy.toFixed(2),
  }));

  const metrics = [
    { label: 'Total Energy', value: `${stats.totalEnergyGenerated.toFixed(1)}`, unit: 'mJ', icon: <Battery className="w-5 h-5 text-emerald-500" />, sub: 'Accumulated' },
    { label: 'Total Steps', value: `${stats.totalSteps}`, unit: '', icon: <Zap className="w-5 h-5 text-blue-500" />, sub: 'Human Traffic' },
    { label: 'Peak Voltage', value: `${stats.peakVoltage.toFixed(1)}`, unit: 'V', icon: <Gauge className="w-5 h-5 text-amber-500" />, sub: 'Single Strike' },
    { label: 'Efficiency', value: `${stats.efficiency}%`, unit: '', icon: <TrendingUp className="w-5 h-5 text-purple-500" />, sub: 'Conversion Rate' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Metrics Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metrics.map((m, i) => (
          <div key={i} className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200 group hover:border-emerald-500 transition-colors">
            <div className="flex justify-between items-start mb-4">
              <div className="p-3 bg-slate-50 rounded-2xl group-hover:bg-emerald-50 transition-colors">
                {m.icon}
              </div>
              <span className="px-3 py-1 bg-slate-100 rounded-full text-[10px] font-bold text-slate-500 uppercase">Live</span>
            </div>
            <div className="flex items-baseline gap-1">
              <h3 className="text-3xl font-mono font-bold text-slate-800">{m.value}</h3>
              <span className="text-sm font-bold text-slate-400">{m.unit}</span>
            </div>
            <p className="text-slate-500 text-sm mt-1">{m.label}</p>
            <div className="mt-4 pt-4 border-t border-slate-50 flex items-center gap-2">
              <span className="text-[10px] text-slate-400 font-bold uppercase">{m.sub}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Voltage Line Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-lg font-bold text-slate-800">Voltage Waveform (AC to DC)</h3>
            <span className="text-xs text-slate-400 font-mono">Real-time Stream</span>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorVoltage" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" hide />
                <YAxis hide />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  labelStyle={{ fontWeight: 'bold' }}
                />
                <Area type="monotone" dataKey="voltage" stroke="#10b981" fillOpacity={1} fill="url(#colorVoltage)" strokeWidth={3} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Power Distribution Chart */}
        <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-200">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-lg font-bold text-slate-800">Energy Generated per Step (mJ)</h3>
            <span className="text-xs text-slate-400 font-mono">Sample Rate: 1Hz</span>
          </div>
          <div className="h-[300px] w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="time" hide />
                <YAxis hide />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="energy" radius={[4, 4, 0, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={Number(entry.energy) > 5 ? '#3b82f6' : '#94a3b8'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
