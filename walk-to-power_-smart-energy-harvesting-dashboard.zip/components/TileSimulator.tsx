
import React, { useState, useEffect } from 'react';
import { Zap, MoveDown, MousePointer2 } from 'lucide-react';
import { EnergyReading } from '../types';

interface TileSimulatorProps {
  onStep: (reading: EnergyReading) => void;
}

const TileSimulator: React.FC<TileSimulatorProps> = ({ onStep }) => {
  const [isPressing, setIsPressing] = useState(false);
  const [pressure, setPressure] = useState(0);

  const handleStep = (magnitude: number) => {
    const voltage = Math.random() * magnitude + 5;
    const current = voltage * (0.01 + Math.random() * 0.05);
    const power = voltage * current;
    const energy = power * 0.2; // 200ms duration approx
    const brightness = Math.min(100, (voltage / 50) * 100);
    
    let stepType: 'Light' | 'Normal' | 'Heavy' = 'Normal';
    if (magnitude < 10) stepType = 'Light';
    else if (magnitude > 35) stepType = 'Heavy';

    onStep({
      timestamp: Date.now(),
      voltage,
      current,
      power,
      energy,
      brightness,
      stepType
    });
  };

  const simulateStep = () => {
    const magnitude = 10 + Math.random() * 40;
    setPressure(magnitude);
    setIsPressing(true);
    handleStep(magnitude);
    setTimeout(() => {
      setIsPressing(false);
      setPressure(0);
    }, 150);
  };

  return (
    <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-200">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Interactive Tile</h2>
          <p className="text-slate-500 text-sm">Simulate physical foot pressure to generate power</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={simulateStep}
            className="bg-slate-900 text-white px-6 py-2 rounded-xl hover:bg-slate-800 transition-colors flex items-center gap-2"
          >
            <Zap className="w-4 h-4 text-emerald-400" />
            Random Step
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
        <div className="flex flex-col items-center">
          <div 
            onMouseDown={() => { setIsPressing(true); setPressure(50); handleStep(50); }}
            onMouseUp={() => { setIsPressing(false); setPressure(0); }}
            className={`
              relative w-64 h-64 rounded-[40px] cursor-pointer transition-all duration-75
              border-4 flex items-center justify-center shadow-2xl
              ${isPressing ? 'scale-95 border-emerald-400 bg-emerald-50' : 'scale-100 border-slate-200 bg-slate-100'}
            `}
          >
            <div className={`absolute inset-0 rounded-[40px] transition-opacity duration-300 ${isPressing ? 'opacity-20' : 'opacity-0'} bg-emerald-400 blur-xl animate-pulse`}></div>
            <div className="text-center z-10 pointer-events-none">
              <MoveDown className={`w-12 h-12 mx-auto mb-2 transition-transform ${isPressing ? 'translate-y-2 text-emerald-600' : 'text-slate-400'}`} />
              <p className={`font-bold ${isPressing ? 'text-emerald-700' : 'text-slate-500'}`}>PRESS TILE</p>
            </div>
            
            {/* Piezo Sensor Markers */}
            <div className="absolute top-4 left-4 w-4 h-4 rounded-full bg-slate-300"></div>
            <div className="absolute top-4 right-4 w-4 h-4 rounded-full bg-slate-300"></div>
            <div className="absolute bottom-4 left-4 w-4 h-4 rounded-full bg-slate-300"></div>
            <div className="absolute bottom-4 right-4 w-4 h-4 rounded-full bg-slate-300"></div>
          </div>
          <p className="mt-6 text-sm text-slate-400 flex items-center gap-2">
            <MousePointer2 className="w-4 h-4" /> Click and hold the tile to generate mechanical pressure
          </p>
        </div>

        <div className="space-y-6">
          <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Live LED Load</h3>
            <div className="flex items-center gap-6">
              <div 
                className="w-20 h-20 rounded-full border-4 border-slate-200 transition-all duration-150"
                style={{ 
                  backgroundColor: `rgba(16, 185, 129, ${pressure / 100})`,
                  boxShadow: pressure > 0 ? `0 0 ${pressure}px rgba(16, 185, 129, 0.8)` : 'none'
                }}
              ></div>
              <div>
                <p className="text-2xl font-mono font-bold text-slate-800">{Math.round(pressure)}%</p>
                <p className="text-slate-500 text-sm">Brightness Intensity</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 rounded-2xl p-6 border border-slate-100">
            <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-4">Piezoelectric Output</h3>
            <div className="flex items-end gap-2">
              <span className="text-4xl font-mono font-bold text-slate-800 tracking-tighter">
                {pressure > 0 ? (pressure * 0.48).toFixed(1) : "0.0"}
              </span>
              <span className="text-xl font-bold text-emerald-500 mb-1">V AC</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TileSimulator;
