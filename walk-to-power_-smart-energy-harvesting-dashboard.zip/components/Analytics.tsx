
import React, { useState, useEffect } from 'react';
import { Brain, Sparkles, TrendingUp, Users, MapPin } from 'lucide-react';
import { analyzeEnergyTrends, getPredictions } from '../services/geminiService';
import { EnergyReading, PredictionData } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

interface AnalyticsProps {
  history: EnergyReading[];
}

const Analytics: React.FC<AnalyticsProps> = ({ history }) => {
  const [analysis, setAnalysis] = useState<string>('Generating AI analysis of recent activity...');
  const [predictions, setPredictions] = useState<PredictionData[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const [text, pred] = await Promise.all([
        analyzeEnergyTrends(history),
        getPredictions()
      ]);
      setAnalysis(text || "No insights available.");
      setPredictions(pred);
      setLoading(false);
    };

    fetchData();
  }, [history.length > 0]);

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-700">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* AI Insight Box */}
        <div className="lg:col-span-1 bg-gradient-to-br from-slate-900 to-slate-800 text-white p-8 rounded-3xl shadow-xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="p-2 bg-emerald-500/20 rounded-xl">
              <Brain className="w-6 h-6 text-emerald-400" />
            </div>
            <h3 className="text-xl font-bold">Smart Analysis</h3>
          </div>
          <div className="space-y-4">
            {loading ? (
              <div className="space-y-3">
                <div className="h-4 bg-slate-700 rounded w-3/4 animate-pulse"></div>
                <div className="h-4 bg-slate-700 rounded w-full animate-pulse"></div>
                <div className="h-4 bg-slate-700 rounded w-5/6 animate-pulse"></div>
              </div>
            ) : (
              <div className="text-slate-300 leading-relaxed font-light text-sm">
                {analysis.split('\n').map((line, i) => (
                  <p key={i} className="mb-2">{line}</p>
                ))}
              </div>
            )}
            <button 
              onClick={() => analyzeEnergyTrends(history).then(setAnalysis)}
              className="mt-4 flex items-center gap-2 text-xs font-bold text-emerald-400 hover:text-emerald-300 transition-colors uppercase tracking-widest"
            >
              <Sparkles className="w-4 h-4" /> Refresh Intelligence
            </button>
          </div>
        </div>

        {/* Prediction Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-500" />
                6-Hour Energy Forecast
              </h3>
              <p className="text-slate-500 text-sm">ML Predicted output based on crowd historicals</p>
            </div>
          </div>
          <div className="h-[300px]">
            {loading ? (
              <div className="w-full h-full flex items-center justify-center bg-slate-50 rounded-2xl border-2 border-dashed border-slate-200">
                <p className="text-slate-400 font-medium">Gathering ML predictions...</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={predictions}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis dataKey="hour" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b'}} />
                  <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#64748b'}} />
                  <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }} />
                  <Bar dataKey="predictedEnergy" fill="#10b981" radius={[10, 10, 0, 0]} name="Predicted (mJ)" />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>
      </div>

      {/* Advanced Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-white p-8 rounded-3xl border border-slate-200">
          <h4 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-500" />
            Crowd Density Projection
          </h4>
          <div className="h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={predictions}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="hour" hide />
                <YAxis hide />
                <Tooltip contentStyle={{ borderRadius: '16px', border: 'none' }} />
                <Line type="monotone" dataKey="expectedCrowdDensity" stroke="#f59e0b" strokeWidth={4} dot={{ r: 6, fill: '#f59e0b', strokeWidth: 0 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-xs text-slate-400 mt-4 text-center italic">Calculated using 1D CNN waveform analysis</p>
        </div>

        <div className="bg-white p-8 rounded-3xl border border-slate-200">
          <h4 className="font-bold text-slate-800 mb-6 flex items-center gap-2">
            <MapPin className="w-5 h-5 text-purple-500" />
            Hotspot Management
          </h4>
          <div className="space-y-4">
            <div className="p-4 bg-slate-50 rounded-2xl flex justify-between items-center border border-slate-100">
              <span className="text-sm font-medium text-slate-600">Active Nodes</span>
              <span className="font-mono font-bold text-slate-800">42/42</span>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl flex justify-between items-center border border-slate-100">
              <span className="text-sm font-medium text-slate-600">Storage Optimization</span>
              <span className="text-emerald-500 text-sm font-bold flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> Enabled
              </span>
            </div>
            <div className="p-4 bg-slate-50 rounded-2xl flex justify-between items-center border border-slate-100">
              <span className="text-sm font-medium text-slate-600">Peak Demand Window</span>
              <span className="font-mono font-bold text-slate-800">17:00 - 19:30</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Analytics;
