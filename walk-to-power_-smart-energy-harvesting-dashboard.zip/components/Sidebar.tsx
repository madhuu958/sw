
import React from 'react';
import { NAVIGATION_ITEMS } from '../constants';
import { Footprints } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <div className="w-64 bg-slate-900 h-screen fixed left-0 top-0 flex flex-col text-white shadow-2xl z-50">
      <div className="p-6 flex items-center gap-3 border-b border-slate-800">
        <div className="bg-emerald-500 p-2 rounded-lg">
          <Footprints className="w-6 h-6 text-slate-900" />
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight">Walk To Power</h1>
          <p className="text-xs text-slate-400 font-mono">v1.0.4-SmartCity</p>
        </div>
      </div>
      
      <nav className="flex-1 mt-6 px-3 space-y-2">
        {NAVIGATION_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              activeTab === item.id 
                ? 'bg-emerald-500 text-slate-900 font-bold shadow-lg shadow-emerald-500/20' 
                : 'text-slate-400 hover:bg-slate-800 hover:text-white'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-4 mt-auto">
        <div className="bg-slate-800/50 rounded-2xl p-4 border border-slate-700">
          <div className="flex items-center gap-2 mb-2">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            <span className="text-xs font-semibold text-emerald-400">ESP32 CONNECTED</span>
          </div>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mb-1">Device ID</p>
          <p className="text-xs font-mono text-slate-300">WP-NODE-X0429</p>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
