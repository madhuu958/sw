
import { GoogleGenAI, Type } from "@google/genai";
import { EnergyReading } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeEnergyTrends(readings: EnergyReading[]) {
  const prompt = `Analyze the following energy harvesting data from human footsteps:
  ${JSON.stringify(readings.slice(-10))}
  
  Provide a brief summary of:
  1. Average energy output efficiency.
  2. Potential crowd density estimation.
  3. Recommendations for infrastructure placement in a smart city context.
  Keep it concise and technical.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        thinkingConfig: { thinkingBudget: 0 }
      }
    });
    return response.text;
  } catch (error) {
    console.error("Gemini Analysis Error:", error);
    return "Unable to perform AI analysis at this time. Please check your connection.";
  }
}

export async function getPredictions() {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: "Predict the energy generation for the next 6 hours in a typical high-traffic railway station using piezoelectric tiles. Output as JSON array of objects with 'hour', 'predictedEnergy' (mJ), and 'expectedCrowdDensity' (percentage).",
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            hour: { type: Type.STRING },
            predictedEnergy: { type: Type.NUMBER },
            expectedCrowdDensity: { type: Type.NUMBER }
          },
          required: ["hour", "predictedEnergy", "expectedCrowdDensity"]
        }
      }
    }
  });
  
  try {
    return JSON.parse(response.text);
  } catch (e) {
    return [];
  }
}
